# NotesApp
 Here i had been used Android Studio by using with JAVA.
